// Painel de configuração da extensão.
// Principal função: CONECTAR o site do ArbPrime (registra a ponte naquele origin),
// que é o que faz o botão "abrir na casa" usar a extensão em vez de só abrir o link.

const $ = (id) => document.getElementById(id);

let currentOrigin = null; // origin da aba ativa (se for http/https)
let currentTabId = null;

document.addEventListener('DOMContentLoaded', init);

async function init() {
  $('version').textContent = 'v' + chrome.runtime.getManifest().version;
  await loadSettings();
  await loadCurrentTab();
  await renderSites();
  wireSettings();
}

// --- aba atual ---
async function loadCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const originEl = $('siteOrigin');
  const stateEl = $('siteState');
  const connectBtn = $('connectBtn');
  const disconnectBtn = $('disconnectBtn');
  const hint = $('connectHint');

  if (!tab || !tab.url || !/^https?:\/\//.test(tab.url)) {
    originEl.textContent = 'Abra a aba do ArbPrime para conectar.';
    stateEl.className = 'site-state state-na';
    stateEl.textContent = '';
    return;
  }

  currentTabId = tab.id;
  currentOrigin = new URL(tab.url).origin;
  originEl.textContent = currentOrigin;

  const sites = await getSites();
  const connected = sites.includes(currentOrigin);

  if (connected) {
    stateEl.className = 'site-state state-on';
    stateEl.textContent = '● Conectado ao ArbPrime';
    disconnectBtn.hidden = false;
    connectBtn.hidden = true;
    hint.hidden = true;
  } else {
    stateEl.className = 'site-state state-off';
    stateEl.textContent = '○ Não conectado';
    connectBtn.hidden = false;
    disconnectBtn.hidden = true;
    hint.hidden = false;
  }

  connectBtn.onclick = onConnect;
  disconnectBtn.onclick = onDisconnect;
}

async function onConnect() {
  if (!currentOrigin) return;
  // Permissão de host TEM que ser pedida num gesto do usuário (este clique).
  const granted = await chrome.permissions.request({ origins: [currentOrigin + '/*'] });
  if (!granted) return;
  const r = await chrome.runtime.sendMessage({ type: 'CONNECT_SITE', origin: currentOrigin });
  if (r?.ok) {
    if (currentTabId != null) chrome.tabs.reload(currentTabId); // ponte só injeta no próximo load
    await loadCurrentTab();
    await renderSites();
  }
}

async function onDisconnect() {
  if (!currentOrigin) return;
  await chrome.runtime.sendMessage({ type: 'DISCONNECT_SITE', origin: currentOrigin });
  try { await chrome.permissions.remove({ origins: [currentOrigin + '/*'] }); } catch { /* ok */ }
  await loadCurrentTab();
  await renderSites();
}

// --- lista de sites conectados ---
async function getSites() {
  const { sites = [] } = await chrome.storage.sync.get('sites');
  return sites;
}

async function renderSites() {
  const sites = await getSites();
  const ul = $('sitesList');
  const empty = $('sitesEmpty');
  ul.innerHTML = '';
  empty.hidden = sites.length > 0;

  for (const origin of sites) {
    const li = document.createElement('li');
    const span = document.createElement('span');
    span.className = 'o';
    span.textContent = origin;
    const rm = document.createElement('button');
    rm.className = 'rm';
    rm.textContent = 'remover';
    rm.onclick = async () => {
      await chrome.runtime.sendMessage({ type: 'DISCONNECT_SITE', origin });
      try { await chrome.permissions.remove({ origins: [origin + '/*'] }); } catch { /* ok */ }
      await loadCurrentTab();
      await renderSites();
    };
    li.append(span, rm);
    ul.appendChild(li);
  }
}

// --- settings ---
async function loadSettings() {
  const { settings = {} } = await chrome.storage.sync.get('settings');
  $('autofill').checked = settings.autofill !== false;
  $('useSearch').checked = settings.useSearch !== false;
  $('scrapeWait').value = Number(settings.scrapeMaxWaitMs) > 0 ? Math.round(settings.scrapeMaxWaitMs / 1000) : 12;
}

function wireSettings() {
  const save = async () => {
    const settings = {
      autofill: $('autofill').checked,
      useSearch: $('useSearch').checked,
      scrapeMaxWaitMs: Math.max(3, Math.min(40, Number($('scrapeWait').value) || 12)) * 1000,
    };
    await chrome.storage.sync.set({ settings });
  };
  $('autofill').addEventListener('change', save);
  $('useSearch').addEventListener('change', save);
  $('scrapeWait').addEventListener('change', save);
}
