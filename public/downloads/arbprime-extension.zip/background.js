// Hub da extensão (service worker MV3). Só ele pode abrir abas (chrome.tabs) e
// registrar content scripts dinâmicos. Estado persistente fica em storage (o SW
// pode ser desligado a qualquer momento), nunca em variável de memória.

const BRIDGE_PREFIX = 'bridge:'; // id dos content scripts dinâmicos da ponte

chrome.runtime.onInstalled.addListener(reconcileBridges);
chrome.runtime.onStartup.addListener(reconcileBridges);

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // Página do arbprime (via content-bridge) pediu pra abrir um jogo.
  if (msg?.type === 'OPEN_GAME') {
    openGame(msg.payload);
    return; // sem resposta
  }

  // Content script da casa acordou e está pedindo o job daquela aba.
  if (msg?.type === 'MAJOVIP_READY' && sender.tab?.id != null) {
    const tabId = sender.tab.id;
    chrome.storage.session.get('jobs').then(({ jobs = {} }) => {
      const job = jobs[tabId] || null;
      if (job) {
        delete jobs[tabId];
        chrome.storage.session.set({ jobs });
      }
      sendResponse({ job });
    });
    return true; // resposta assíncrona
  }

  // Painel: conectar/desconectar um site do ArbPrime (registra a ponte naquele origin).
  if (msg?.type === 'CONNECT_SITE' && msg.origin) {
    connectSite(msg.origin).then(() => sendResponse({ ok: true })).catch((e) => sendResponse({ ok: false, error: String(e) }));
    return true;
  }
  if (msg?.type === 'DISCONNECT_SITE' && msg.origin) {
    disconnectSite(msg.origin).then(() => sendResponse({ ok: true })).catch((e) => sendResponse({ ok: false, error: String(e) }));
    return true;
  }
});

// --- abrir jogo ---
async function openGame(payload) {
  const url = payload?.url; // página do dia da casa (ex.: majovip /esportes/futebol?data=...)
  if (!url) { console.warn('[ArbPrime] OPEN_GAME sem url', payload); return; }
  const tab = await chrome.tabs.create({ url });
  if (tab.id == null) return;
  const { jobs = {} } = await chrome.storage.session.get('jobs');
  jobs[tab.id] = payload; // o content script da casa pega esse job ao carregar
  await chrome.storage.session.set({ jobs });
  console.log('[ArbPrime] bg abriu aba', tab.id, '→', url, '| bet:', payload.bet);
}

// --- sites conectados (ponte registrada dinamicamente) ---
async function getSites() {
  const { sites = [] } = await chrome.storage.sync.get('sites');
  return sites;
}

async function connectSite(origin) {
  const id = BRIDGE_PREFIX + origin;
  try { await chrome.scripting.unregisterContentScripts({ ids: [id] }); } catch { /* não existia */ }
  await chrome.scripting.registerContentScripts([
    { id, matches: [origin + '/*'], js: ['content-bridge.js'], runAt: 'document_start', persistAcrossSessions: true },
  ]);
  const sites = await getSites();
  if (!sites.includes(origin)) {
    sites.push(origin);
    await chrome.storage.sync.set({ sites });
  }
}

async function disconnectSite(origin) {
  const id = BRIDGE_PREFIX + origin;
  try { await chrome.scripting.unregisterContentScripts({ ids: [id] }); } catch { /* já não estava */ }
  const sites = (await getSites()).filter((s) => s !== origin);
  await chrome.storage.sync.set({ sites });
}

// Re-garante o registro das pontes salvas (idempotente; cobre updates/edge cases).
async function reconcileBridges() {
  for (const origin of await getSites()) {
    try { await connectSite(origin); } catch { /* permissão pode ter sido revogada */ }
  }
}
