// Hub da extensão (service worker MV3). Só ele pode abrir abas (chrome.tabs) e
// registrar content scripts dinâmicos. Estado persistente fica em storage (o SW
// pode ser desligado a qualquer momento), nunca em variável de memória.

const BRIDGE_PREFIX = 'bridge:'; // id dos content scripts dinâmicos da ponte

chrome.runtime.onInstalled.addListener(reconcileBridges);
chrome.runtime.onStartup.addListener(reconcileBridges);

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // Página do arbprime (via content-bridge) pediu pra abrir um jogo.
  if (msg?.type === 'OPEN_GAME') {
    openGame(msg.payload);
    return; // sem resposta
  }

  // Content script da casa acordou e está pedindo o job daquela aba.
  if ((msg?.type === 'MAJOVIP_READY' || msg?.type === 'BETSBOLA_READY') && sender.tab?.id != null) {
    const tabId = sender.tab.id;
    chrome.storage.session.get('jobs').then(({ jobs = {} }) => {
      const job = jobs[tabId] || null;
      if (job) {
        delete jobs[tabId];
        chrome.storage.session.set({ jobs });
      }
      sendResponse({ job });
    });
    return true; // resposta assíncrona
  }

  // betsbola_vip: o content script (mundo isolado) já achou camp_id + jog_odd_id;
  // executamos as funções da PÁGINA no mundo MAIN (o isolado não as enxerga).
  if (msg?.type === 'BETSBOLA_EXEC' && sender.tab?.id != null) {
    betsbolaExec(sender.tab.id, msg);
    return; // sem resposta
  }

  // Painel: conectar/desconectar um site do ArbPrime (registra a ponte naquele origin).
  if (msg?.type === 'CONNECT_SITE' && msg.origin) {
    connectSite(msg.origin).then(() => sendResponse({ ok: true })).catch((e) => sendResponse({ ok: false, error: String(e) }));
    return true;
  }
  if (msg?.type === 'DISCONNECT_SITE' && msg.origin) {
    disconnectSite(msg.origin).then(() => sendResponse({ ok: true })).catch((e) => sendResponse({ ok: false, error: String(e) }));
    return true;
  }
});

// --- abrir jogo ---
async function openGame(payload) {
  const url = payload?.url; // página do dia da casa (ex.: majovip /esportes/futebol?data=...)
  if (!url) { console.warn('[ArbPrime] OPEN_GAME sem url', payload); return; }
  const tab = await chrome.tabs.create({ url });
  if (tab.id == null) return;
  const { jobs = {} } = await chrome.storage.session.get('jobs');
  jobs[tab.id] = payload; // o content script da casa pega esse job ao carregar
  await chrome.storage.session.set({ jobs });
  console.log('[ArbPrime] bg abriu aba', tab.id, '→', url, '| bet:', payload.bet);
}

// --- betsbola_vip: dirige a página no mundo MAIN ---
// Carrega o campeonato (ConsultarJogos), abre as odds (MaisOdds) e adiciona a
// seleção na cédula (CheckOdd2Local). Roda no contexto da PÁGINA (world:'MAIN'),
// então enxerga as funções/variáveis globais do site e ignora o CSP dele.
async function betsbolaExec(tabId, { campId, eventId, jogOddId, stake }) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      args: [campId, Number(eventId), jogOddId, stake],
      func: async (campId, eventId, jogOddId, stake) => {
        const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
        const log = (...a) => console.log('[ArbPrime/betsbola]', ...a);
        try {
          // espera a página inicializar (dados base + funções)
          for (let i = 0; i < 40 && typeof window.ConsultarJogos !== 'function'; i++) await sleep(150);
          if (typeof window.ConsultarJogos !== 'function') { log('funcoes da pagina nao prontas'); return; }

          // 1) carrega o campeonato → coloca o jogo em listaJogos
          if (campId != null) {
            window.ConsultarJogos(campId, 10);
            for (let i = 0; i < 40; i++) {
              const jl = typeof window.ProcurarJogoLocal === 'function' ? window.ProcurarJogoLocal(eventId) : undefined;
              if (jl) break;
              await sleep(150);
            }
          }
          log('campeonato carregado, jogo', eventId);

          // sem odd casada: só deixa o jogo/lista visível
          if (!jogOddId) { log('sem jog_odd_id — abriu o jogo sem auto-selecionar'); return; }

          // 2) carrega TODAS as odds do jogo (popula o array global maisOdds)
          if (typeof window.MaisOdds === 'function') {
            window.MaisOdds(eventId, 10);
            await sleep(1600);
          }

          // 3) adiciona a seleção na cédula
          if (typeof window.CheckOdd2Local === 'function') {
            window.CheckOdd2Local(eventId, jogOddId);
            await sleep(500);
            log('CheckOdd2Local chamado', eventId, jogOddId, '| bilhete:', localStorage.bilhete);
          }

          // fecha o modal de "mais odds" se ficou aberto
          try { document.querySelectorAll('.modalWindow2, .modalBack').forEach((e) => { e.style.display = 'none'; }); } catch { /* */ }

          // 4) stake sugerido (best-effort): preenche o 1º input de valor da cédula
          if (stake != null && stake !== '') {
            const inp = [...document.querySelectorAll('input')].find(
              (i) => /valor|aposta|stake|aposta/i.test((i.placeholder || '') + ' ' + (i.id || '') + ' ' + (i.name || '')),
            );
            if (inp) {
              const d = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
              if (d && d.set) d.set.call(inp, String(stake)); else inp.value = String(stake);
              inp.dispatchEvent(new Event('input', { bubbles: true }));
              inp.dispatchEvent(new Event('change', { bubbles: true }));
            }
          }
        } catch (e) { console.warn('[ArbPrime/betsbola] erro no mundo MAIN:', e); }
      },
    });
  } catch (e) {
    console.warn('[ArbPrime] betsbolaExec falhou:', e);
  }
}

// --- sites conectados (ponte registrada dinamicamente) ---
async function getSites() {
  const { sites = [] } = await chrome.storage.sync.get('sites');
  return sites;
}

async function connectSite(origin) {
  const id = BRIDGE_PREFIX + origin;
  try { await chrome.scripting.unregisterContentScripts({ ids: [id] }); } catch { /* não existia */ }
  await chrome.scripting.registerContentScripts([
    { id, matches: [origin + '/*'], js: ['content-bridge.js'], runAt: 'document_start', persistAcrossSessions: true },
  ]);
  const sites = await getSites();
  if (!sites.includes(origin)) {
    sites.push(origin);
    await chrome.storage.sync.set({ sites });
  }
}

async function disconnectSite(origin) {
  const id = BRIDGE_PREFIX + origin;
  try { await chrome.scripting.unregisterContentScripts({ ids: [id] }); } catch { /* já não estava */ }
  const sites = (await getSites()).filter((s) => s !== origin);
  await chrome.storage.sync.set({ sites });
}

// Re-garante o registro das pontes salvas (idempotente; cobre updates/edge cases).
async function reconcileBridges() {
  for (const origin of await getSites()) {
    try { await connectSite(origin); } catch { /* permissão pode ter sido revogada */ }
  }
}
