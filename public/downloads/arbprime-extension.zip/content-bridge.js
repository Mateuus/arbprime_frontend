// Ponte entre a PÁGINA do arbprime e a extensão.
// A página (React) não enxerga as APIs chrome.* — então ela conversa por
// window.postMessage e ESTE content script repassa pro background (e vice-versa).
//
// Detecção à prova de corrida: marca o <html> com data-arbprime-ext no
// document_start (a página lê isso de forma SÍNCRONA, sem depender de ping).

(() => {
  const ORIGIN = window.location.origin; // só aceita/envia da própria página

  // marcador síncrono de "extensão presente" (lido por isExtensionKnownInstalled)
  try {
    document.documentElement.setAttribute('data-arbprime-ext', chrome.runtime.getManifest().version);
  } catch { /* document ainda não pronto, ignorável */ }

  function reply(type) {
    window.postMessage(
      { __arbprimeExt: 1, type, version: chrome.runtime.getManifest().version },
      ORIGIN
    );
  }

  window.addEventListener('message', (ev) => {
    if (ev.source !== window || ev.origin !== ORIGIN) return;
    const msg = ev.data;
    if (!msg || msg.__arbprime !== 1) return;

    if (msg.type === 'PING') { reply('PONG'); return; }
    if (msg.type === 'OPEN_GAME' && msg.payload) {
      console.log('[ArbPrime] bridge → background OPEN_GAME', msg.payload);
      chrome.runtime.sendMessage({ type: 'OPEN_GAME', payload: msg.payload });
    }
  });

  reply('READY');
})();
