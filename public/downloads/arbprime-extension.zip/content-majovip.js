// Roda DENTRO da majovip. Pega o job do background (jogo + aposta escolhidos no
// ArbPrime), ACHA + CLICA o jogo na página do dia e, se vier `job.bet`, AUTO-ADICIONA
// a seleção na cédula (BILHETE) clicando na odd certa (o site preenche o
// localStorage `itens-bilhete-esportivo` sozinho — nós só clicamos no elemento).
//
// DOM da majovip (Angular), conferido via puppeteer em 2026-06:
//   LISTA DO DIA:  div.jogo > .indentificacao (abre o evento) / .nome-time (times) / .horario
//   busca:         input[placeholder="Pesquisar"]  (filtra a lista inteira)
//   EVENTO ABERTO: cada mercado = div.tipo-aposta com classe semântica
//                  (resultado_final, dupla_chance, ambos_marcam, gols_partida,
//                   total_gols_casa, total_gols_fora, empate_anula_aposta, handicap…)
//                  título = .header-tipo-aposta (.collapsed quando fechado)
//                  odd    = .inner-odd.odd-enabled > .nome-odd + .valor
//   cédula:        input[placeholder="Valor"] (stake)
//
// O eventId do ArbPrime NÃO aparece no DOM → casa o JOGO por nome dos times e a
// ODD por (seção do mercado + rótulo da seleção). Gols usam rótulo "+X.5"/"-X.5".

(async () => {
  let res = null;
  try { res = await chrome.runtime.sendMessage({ type: 'MAJOVIP_READY' }); } catch { return; }
  const job = res && res.job;
  if (!job) return;

  console.log('[ArbPrime] job recebido na majovip:', job);
  const cfg = await getConfig();
  // nunca estoura erro na página da casa (se algo falhar, fica em silêncio).
  try {
    const abriu = await abrirJogo(job, cfg);
    console.log('[ArbPrime] abrir jogo:', abriu, '|', job.home, 'x', job.away);
    if (abriu !== 'ok') return; // não achou o jogo / lista não carregou
    if (cfg.autofill && job.bet) {
      const r = await fillBetslip(job.bet, cfg);
      console.log('[ArbPrime] preencher cédula:', r, '| bet:', job.bet);
    }
  } catch (e) { console.warn('[ArbPrime] erro no fluxo majovip:', e); }
})();

async function getConfig() {
  const { settings = {} } = await chrome.storage.sync.get('settings');
  return {
    maxWaitMs: Number(settings.scrapeMaxWaitMs) > 0 ? Number(settings.scrapeMaxWaitMs) : 12000,
    useSearch: settings.useSearch !== false,
    autofill: settings.autofill !== false, // padrão: preencher a cédula
  };
}

// ── helpers gerais ───────────────────────────────────────────────────────────
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const norm = (s) =>
  (s || '').toUpperCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^A-Z0-9]/g, '');

// ── achar + abrir o jogo (página do dia) ─────────────────────────────────────
function teamEq(a, b) {
  if (!a || !b) return false;
  if (a === b) return true;
  const [s, l] = a.length <= b.length ? [a, b] : [b, a];
  return s.length >= 4 && l.includes(s);
}
function matchJogo(jogo, H, A) {
  const ns = [...jogo.querySelectorAll('.nome-time')].map((n) => norm(n.innerText));
  if (ns.length < 2) return false;
  return (teamEq(ns[0], H) && teamEq(ns[1], A)) || (teamEq(ns[0], A) && teamEq(ns[1], H));
}
function acharJogo(H, A) {
  for (const j of document.querySelectorAll('.jogo')) if (matchJogo(j, H, A)) return j;
  return null;
}
async function esperarJogo(H, A, ms) {
  const fim = Date.now() + ms;
  do { const j = acharJogo(H, A); if (j) return j; await sleep(400); } while (Date.now() < fim);
  return null;
}
function acharBusca() {
  return [...document.querySelectorAll('input')].find((i) => /pesquis/i.test(i.placeholder || '')) || null;
}
// Angular ngModel ouve 'input': seta value pelo setter nativo e dispara o evento.
function setNativeValue(input, text) {
  input.focus();
  const d = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
  if (d && d.set) d.set.call(input, text); else input.value = text;
  input.dispatchEvent(new Event('input', { bubbles: true }));
  input.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));
}
function searchToken(rawName) {
  const w = (rawName || '').split(/\s+/).filter((x) => x.replace(/[^A-Za-zÀ-ÿ0-9]/g, '').length >= 4);
  w.sort((a, b) => b.length - a.length);
  return w[0] || rawName || '';
}
async function abrirJogo(job, cfg) {
  const H = norm(job.home), A = norm(job.away);
  if (!H || !A) return 'sem-nomes';
  const fim = Date.now() + cfg.maxWaitMs;
  const restante = () => Math.max(1000, fim - Date.now());

  let jogo = await esperarJogo(H, A, Math.min(3500, cfg.maxWaitMs));

  // Se a lista do dia nem carregou (.jogo == 0), o back-end da casa está fora/lento
  // (center.weebet.tech 504). NÃO mexer na busca: digitar dispara o
  // filtrarCampeonatos da casa, que quebra sem dados. Sai em silêncio.
  if (!jogo && document.querySelectorAll('.jogo').length === 0) return 'lista-nao-carregou';

  if (!jogo && cfg.useSearch) {
    const input = acharBusca();
    if (input) {
      for (const token of [searchToken(job.home), searchToken(job.away)]) {
        if (!token) continue;
        setNativeValue(input, token);
        jogo = await esperarJogo(H, A, Math.min(5000, restante()));
        if (jogo) break;
        setNativeValue(input, ''); await sleep(300);
      }
    }
  }
  if (!jogo) jogo = await esperarJogo(H, A, restante());
  if (!jogo) return 'nao-achado';

  (jogo.querySelector('.indentificacao') || jogo.querySelector('[style*="cursor"]') || jogo).click();
  return 'ok';
}

// ── tradutor: mercado do ArbPrime → seção da majovip ─────────────────────────
// nosso slug (parte antes do ':') → classe da .tipo-aposta no evento aberto.
const SECTION_BY_SLUG = {
  'match-winner': 'resultado_final',
  'double-chance': 'dupla_chance',
  'both-teams-to-score': 'ambos_marcam',
  'both-teams-score': 'ambos_marcam',
  'draw-no-bet': 'empate_anula_aposta',
  'total-goals-over-under': 'gols_partida',
  'total-goals-home-over-under': 'total_gols_casa',
  'total-goals-away-over-under': 'total_gols_fora',
};

// lê over/under + linha de um rótulo de gols, nos DOIS formatos que a majovip usa:
//   "Gols na Partida": "+2.5 Gls" / "-1.5" / "-0.5"
//   "Casa/Fora - Total de Gols": "Mais de 1.5" / "Menos de 1.5"
function goalLineFromLabel(label) {
  const s = (label || '').trim();
  const m = s.match(/(\d+(?:\.\d+)?)/);
  if (!m) return null;
  let ou = null;
  if (/menos/i.test(s)) ou = 'under';
  else if (/mais/i.test(s)) ou = 'over';
  else { const sg = (s.match(/([+\-])\s*\d/) || [])[1]; if (sg === '+') ou = 'over'; else if (sg === '-') ou = 'under'; }
  return ou ? { ou, num: parseFloat(m[1]) } : null;
}
function goalNum(v) {
  const n = Number(String(v).replace(/[^\d.]/g, ''));
  return Number.isFinite(n) ? n : null;
}

// dada a perna, retorna um predicado (rótulo da odd) → bool, identificando a seleção
function oddMatcher(slug, option, handicap) {
  const o = (option || '').trim().toLowerCase();
  const N = (s) => norm(s);

  if (slug === 'match-winner' || slug === 'draw-no-bet') {
    const map = { home: 'CASA', away: 'FORA', draw: 'EMPATE' };
    const want = map[o];
    return want ? (label) => N(label) === want : null;
  }
  if (slug === 'double-chance') {
    // site usa rótulo escrito: 1X="Casa ou Empate", X2="Fora ou Empate", 12="Casa ou Fora"
    const map = { '1X': ['CASA', 'EMPATE'], 'X2': ['FORA', 'EMPATE'], '12': ['CASA', 'FORA'] };
    const want = map[N(option)];
    return want ? (label) => { const L = N(label); return want.every((w) => L.includes(w)); } : null;
  }
  if (slug === 'both-teams-to-score' || slug === 'both-teams-score') {
    const yes = o === 'yes' || o === 'sim';
    return (label) => { const L = N(label); return yes ? L.includes('SIM') : L.includes('NAO'); };
  }
  if (slug.startsWith('total-goals')) {
    const ou = o.startsWith('mais') ? 'over' : o.startsWith('menos') ? 'under' : null;
    const num = goalNum(handicap != null && handicap !== '' ? handicap : option);
    if (!ou || num == null) return null;
    return (label) => { const p = goalLineFromLabel(label); return !!p && p.ou === ou && p.num === num; };
  }
  return null;
}

// ── preencher a cédula ───────────────────────────────────────────────────────
async function esperarEvento(ms) {
  const fim = Date.now() + ms;
  do { if (document.querySelector('.tipo-aposta')) return true; await sleep(300); } while (Date.now() < fim);
  return false;
}

function oddsDaSecao(sec) {
  return [...sec.querySelectorAll('.inner-odd.odd-enabled')];
}

async function acharSecaoComOdds(sectionClass, ms) {
  const fim = Date.now() + ms;
  do {
    // prioriza a aba ativa (Tempo Regular); senão qualquer ocorrência. Há cópias
    // duplicadas (uma vazia, "<!---->") — ignoramos as sem odds.
    const cands = [
      ...document.querySelectorAll('.tab-pane.active .tipo-aposta.' + sectionClass),
      ...document.querySelectorAll('.tipo-aposta.' + sectionClass),
    ];
    // 1) materializa as virtualizadas e prefere as que JÁ têm odds (mesmo colapsadas
    //    as odds ficam no DOM e são clicáveis — NÃO expandir, senão o Angular
    //    re-renderiza e some com elas momentaneamente).
    for (const sec of cands) sec.scrollIntoView({ block: 'center' });
    await sleep(300);
    for (const sec of cands) if (oddsDaSecao(sec).length) return sec;
    // 2) último recurso: expandir as colapsadas que ainda não renderizaram odds
    for (const sec of cands) {
      const hdr = sec.querySelector('.header-tipo-aposta.collapsed');
      if (hdr) { hdr.click(); await sleep(500); if (oddsDaSecao(sec).length) return sec; }
    }
    await sleep(300);
  } while (Date.now() < fim);
  return null;
}

function setStake(valor) {
  const inp =
    [...document.querySelectorAll('input')].find((i) => /valor/i.test(i.placeholder || '')) ||
    [...document.querySelectorAll('input[type="number"]')].pop();
  if (inp) setNativeValue(inp, String(valor));
}

async function fillBetslip(bet, cfg) {
  const slug = (bet.market || '').split(':')[0];

  // 1º/2º tempo ficam em outra aba do evento — ainda não suportado: deixa o jogo aberto.
  if (/-(1st|2nd)-half$/.test(slug)) return 'tempo-nao-suportado';

  const sectionClass = SECTION_BY_SLUG[slug];
  if (!sectionClass) return 'mercado-nao-mapeado:' + slug;

  const matcher = oddMatcher(slug, bet.option, bet.handicap);
  if (!matcher) return 'opcao-nao-mapeada';

  if (!(await esperarEvento(8000))) return 'evento-nao-abriu';

  const sec = await acharSecaoComOdds(sectionClass, Math.min(8000, cfg.maxWaitMs));
  if (!sec) return 'secao-nao-achada:' + sectionClass;

  const odd = oddsDaSecao(sec).find((el) => matcher((el.querySelector('.nome-odd') || {}).innerText || ''));
  if (!odd) return 'odd-nao-achada';

  odd.click(); // o site grava em localStorage itens-bilhete-esportivo
  await sleep(400);
  if (bet.stake != null && bet.stake !== '') setStake(bet.stake);
  return 'ok';
}
