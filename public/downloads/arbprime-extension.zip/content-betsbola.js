// Roda DENTRO da betsbola_vip (betsbolavip.com). Pega o job do background (jogo +
// aposta escolhidos no ArbPrime), descobre o `camp_id` e o `jog_odd_id` pela API
// JSON pública da casa (mesma origem) e manda o background EXECUTAR no mundo MAIN
// as funções da própria página (ConsultarJogos → MaisOdds → CheckOdd2Local) que
// carregam o campeonato, abrem as odds e adicionam a seleção na cédula (BILHETE).
//
// Por que mundo MAIN: o content script roda em mundo ISOLADO e NÃO enxerga as
// funções globais da página (CheckOdd2Local, MaisOdds, ConsultarJogos, listaJogos).
// Quem chama essas funções é o background via chrome.scripting (world:'MAIN'),
// imune ao CSP do site. Aqui só fazemos fetch (mesma origem) + o casamento da perna.
//
// Mecânica da casa (conferida ao vivo via puppeteer em 2026-06):
//   API:  GET /futebolapi/api/CampJogo/getEvents/10   → todos os jogos (acha camp_id)
//         GET /futebolapi/api/CampJogo/getOdds/<id>   → odds do jogo c/ jog_odd_id
//   página: ConsultarJogos(campId) carrega o campeonato em listaJogos;
//           MaisOdds(eventId,10) popula o array global `maisOdds`;
//           CheckOdd2Local(eventId, jogOddId) → grava em localStorage.bilhete.
//   ⚠️ o bilhete SÓ adiciona se o evento estiver em listaJogos (daí o ConsultarJogos).

// Slugs da família "sabets" (betsbola_vip + clones com coletor próprio). Todos
// rodam o MESMO skin em domínios diferentes, com a mesma API /futebolapi e as
// mesmas funções globais — então este content script serve a todos.
const SABETS = ['betsbola_vip', 'betsbola_pro', 'esportenet_show', 'esportepe'];

(async () => {
  let res = null;
  try { res = await chrome.runtime.sendMessage({ type: 'BETSBOLA_READY' }); } catch { return; }
  const job = res && res.job;
  if (!job || !SABETS.includes((job.bookmaker || '').toLowerCase())) return;

  console.log('[ArbPrime] job recebido na', job.bookmaker, ':', job);
  const cfg = await getConfig();
  const eventId = Number(job.eventId);
  if (!eventId) { console.warn('[ArbPrime] betsbola sem eventId'); return; }

  try {
    // 1) camp_id do jogo (necessário pro ConsultarJogos que popula listaJogos)
    const campId = await acharCampId(eventId);
    console.log('[ArbPrime] betsbola camp_id:', campId, '| evento', eventId);

    // 2) jog_odd_id da seleção (se houver aposta + autofill ligado)
    let jogOddId = null;
    if (cfg.autofill && job.bet) {
      jogOddId = await acharJogOddId(eventId, job.bet);
      console.log('[ArbPrime] betsbola jog_odd_id:', jogOddId, '| bet:', job.bet);
    }

    // 3) executa no mundo MAIN (background) as funções da página
    await chrome.runtime.sendMessage({
      type: 'BETSBOLA_EXEC',
      campId,
      eventId,
      jogOddId,
      stake: job.bet ? job.bet.stake : null,
    });
  } catch (e) {
    console.warn('[ArbPrime] erro no fluxo betsbola:', e);
  }
})();

async function getConfig() {
  const { settings = {} } = await chrome.storage.sync.get('settings');
  return { autofill: settings.autofill !== false };
}

// ── API da casa (mesma origem) ───────────────────────────────────────────────
async function apiJson(path) {
  const r = await fetch(path, { headers: { Accept: 'application/json' }, credentials: 'include' });
  if (!r.ok) throw new Error('HTTP ' + r.status + ' em ' + path);
  return r.json();
}

// getEvents devolve [{Name, Value:"<json>", Key}] OU já o objeto — normaliza.
function unwrap(arr) {
  return (Array.isArray(arr) ? arr : []).map((w) => {
    if (w && typeof w.Value === 'string') { try { return JSON.parse(w.Value); } catch { return null; } }
    return w;
  }).filter(Boolean);
}

async function acharCampId(eventId) {
  const events = unwrap(await apiJson('/futebolapi/api/CampJogo/getEvents/10'));
  const ev = events.find((e) => Number(e.camp_jog_id) === eventId);
  return ev ? ev.camp_id : null;
}

async function acharJogOddId(eventId, bet) {
  const odds = unwrap(await apiJson('/futebolapi/api/CampJogo/getOdds/' + eventId));
  const odd = matchOdd(odds, bet.market, bet.option, bet.handicap);
  return odd ? odd.jog_odd_id : null;
}

// ── casamento perna (ArbPrime) → odd da casa (mercado_id + descricao_sem_categ) ─
// Espelha o processSaApiMarkets do arbbetting_master, no sentido inverso.
const N = (s) => (s || '').toString().trim().toLowerCase();

function matchOdd(odds, market, option, handicap) {
  const slug = (market || '').split(':')[0];
  const opt = N(option);
  const sc = (o) => N(o.descricao_sem_categ || o.descricao);

  // Vencedor (1X2) — mercado_id 1
  if (slug === 'match-winner') {
    const want = { home: 'casa', draw: 'empate', away: 'fora' }[opt];
    return want ? odds.find((o) => o.mercado_id === 1 && sc(o) === want) : null;
  }
  // Dupla Chance — mercado_id 25, descricao "1X"/"X2"/"1-2"
  if (slug === 'double-chance') {
    const want = { '1x': '1x', x2: 'x2', '12': '1-2' }[opt];
    return want ? odds.find((o) => o.mercado_id === 25 && sc(o) === want) : null;
  }
  // Empate Anula Aposta — mercado_id 10, "Casa"/"Fora". Perna pode vir home/away ou HNB/ANB.
  if (slug === 'draw-no-bet') {
    const home = opt === 'home' || opt === 'hnb' || /casa/.test(opt);
    return odds.find((o) => o.mercado_id === 10 && sc(o) === (home ? 'casa' : 'fora'));
  }
  // Ambas Marcam — mercado_id 30, "Sim"/"Não"
  if (slug === 'both-teams-to-score' || slug === 'both-teams-score') {
    const yes = opt === 'yes' || opt === 'sim';
    return odds.find((o) => o.mercado_id === 30 && (yes ? /sim/.test(sc(o)) : /n[aã]o/.test(sc(o))));
  }
  // Par/Ímpar — mercado_id 35
  if (slug === 'odd-even' || slug === 'goals-odd-even') {
    const odd = /impar|ímpar|odd/.test(opt);
    return odds.find((o) => o.mercado_id === 35 && (odd ? /[íi]mpar/.test(sc(o)) : /par/.test(sc(o)) && !/[íi]mpar/.test(sc(o))));
  }
  // Total de Gols Over/Under — 200 (jogo), 210 (casa), 215 (fora).
  // descricao na betsbola_vip = "+2.5"/"-2.5" (sinal = over/under); também aceita "Acima/Abaixo".
  if (slug.startsWith('total-goals')) {
    const mid = slug.includes('home') ? 210 : slug.includes('away') ? 215 : 200;
    const line = Math.abs(parseFloat(handicap != null && handicap !== '' ? handicap : option));
    if (!Number.isFinite(line)) return null;
    const isOver = /^mais|over|acima/.test(opt) || /^\+/.test((option || '').toString().trim());
    const isUnder = /^menos|under|abaixo/.test(opt) || /^-/.test((option || '').toString().trim());
    if (!isOver && !isUnder) return null;
    return odds.find((o) => {
      if (o.mercado_id !== mid) return false;
      const d = sc(o);
      const m = d.match(/-?\d+(?:\.\d+)?/);
      if (!m || Math.abs(parseFloat(m[0])) !== line) return false;
      const dOver = /^\+/.test(d) || /acima|mais/.test(d);
      const dUnder = /^-/.test(d) || /abaixo|menos/.test(d);
      return isOver ? dOver : dUnder;
    });
  }
  return null; // mercado ainda não mapeado → abre o jogo, sem auto-selecionar
}
